package com.example.iothealthcare;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.sql.Connection;

public class RegisterActivity extends AppCompatActivity {

    EditText txtname,txtphone,txtemail,txtbdate,txtpassword;
    Spinner spngender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        txtbdate=findViewById(R.id.txtbdate);
        txtemail=findViewById(R.id.txtemail);
        txtname=findViewById(R.id.txtname);
        txtpassword=findViewById(R.id.txtpassword);
        txtphone=findViewById(R.id.txtphone);
        spngender=findViewById(R.id.spngender);
    }

    public void register(View view) {
        if(txtphone.getText().toString().isEmpty())
        {
            txtphone.setError("Please enter Phone");
            txtphone.requestFocus();
        }
        else
        {
            if(txtpassword.getText().toString().isEmpty())
            {
                txtpassword.setError("Please enter password");
                txtpassword.requestFocus();
            }
            else
            {
                Database db=new Database();
                Connection conn=db.ConnectDB();
                if(conn==null)
                {
                    Toast.makeText(this, "Please Check Internet Access", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String msg=db.RunDML("insert into student values(Default,'"+txtname.getText()+"','"+txtphone.getText()+"','"+txtemail.getText()+"','"+txtpassword.getText()+"','"+spngender.getSelectedItem()+"','"+txtbdate.getText()+"')");
                    if(msg.equals("Ok"))
                    {
                        AlertDialog.Builder mm=new AlertDialog.Builder(RegisterActivity.this);
                        mm.setIcon(R.drawable.logo);
                        mm.setTitle("Register.....");
                        mm.setMessage("Account has been created");
                        mm.setPositiveButton("Thanks",null);
                        mm.create();
                        mm.show();
                    }
                    else
                    {
                        Toast.makeText(this, "Error is "+msg, Toast.LENGTH_SHORT).show();
                    }

                }
            }
        }



    }
}