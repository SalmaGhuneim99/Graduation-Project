package com.example.iothealthcare;

public class ReadsData {

    String Date,oxogen,temp,StudentID,heart;

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getOxogen() {
        return oxogen;
    }

    public void setOxogen(String oxogen) {
        this.oxogen = oxogen;
    }

    public String getTemp() {
        return temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getStudentID() {
        return StudentID;
    }

    public void setStudentID(String studentID) {
        StudentID = studentID;
    }

    public String getHeart() {
        return heart;
    }

    public void setHeart(String heart) {
        this.heart = heart;
    }
}
