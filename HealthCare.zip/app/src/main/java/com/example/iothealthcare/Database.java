package com.example.iothealthcare;

import android.os.StrictMode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

    Connection conn=null;
    public Connection ConnectDB() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            //Class.forName("net.sourceforge.jtds.jdbc.Driver");
            Class.forName("com.mysql.jdbc.Driver");
            //conn= DriverManager.getConnection("jdbc:jtds:sqlserver://sql5092.site4now.net/db_a87e92_iothealthdb","db_a87e92_iothealthdb_admin","ABC@123456");
            conn= DriverManager.getConnection("jdbc:mysql://mysql5046.site4now.net/db_a87e92_iotheal","a87e92_iotheal","ABC@123456");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;

    }
    // Using for insert or update or delete
    public String RunDML(String st)
    {
        Statement omar= null;
        try {
            omar = conn.createStatement();
            omar.executeUpdate(st);
            return  "Ok";

        } catch (SQLException e) {
            return e.getMessage();

        }




    }
    public ResultSet RunSearch(String st)
    {
        ResultSet rs=null;
        try {
            Statement statement=conn.createStatement();
            rs=statement.executeQuery(st);


        } catch (SQLException e) {
            e.printStackTrace();
        }
            return rs;

    }
}
