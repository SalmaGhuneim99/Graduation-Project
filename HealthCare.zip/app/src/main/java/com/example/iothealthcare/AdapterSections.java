package com.example.iothealthcare;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterSections extends ArrayAdapter<ReadsData> {

    Context c;
    ArrayList<ReadsData> ass;

    public AdapterSections(Context context, ArrayList<ReadsData> cont) {
        super(context, R.layout.readslayout,cont);
        c=context;
        ass=cont;
    }

    class Holder
    {
        ImageView imgdept;
        TextView txtdate;
        TextView txtvalue;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position

        ReadsData data = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view

        Holder viewHolder; // view lookup cache stored in tag

        if (convertView == null) {

            viewHolder = new Holder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.readslayout, parent, false);

            viewHolder.txtdate = (TextView) convertView.findViewById(R.id.txtdate);
            viewHolder.txtvalue = (TextView) convertView.findViewById(R.id.txtvalue);

            viewHolder.imgdept = (ImageView) convertView.findViewById(R.id.imglogo);



            convertView.setTag(viewHolder);

        } else {
            viewHolder = (Holder) convertView.getTag();
        }
        double value=Double.parseDouble(data.getOxogen().toString());
        double from=Double.parseDouble(data.getTemp().toString());
        double to=Double.parseDouble(data.getHeart().toString());


        viewHolder.txtdate.setText(data.getDate());
        viewHolder.txtvalue.setText("Temp : "+data.getTemp()+"\nOxagen : "+data.getOxogen()+"\nHear Rate : "+data.getHeart());

        if(MainActivity.type.equals("up")) {
            viewHolder.imgdept.setImageDrawable(convertView.getResources().getDrawable(R.drawable.red));
        }
        else
        {
            viewHolder.imgdept.setImageDrawable(convertView.getResources().getDrawable(R.drawable.green));
        }

        // Return the completed view to render on screen
        return convertView;
    }


}
