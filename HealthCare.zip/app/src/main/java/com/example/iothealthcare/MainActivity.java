package com.example.iothealthcare;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static String type=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "Welcome : "+LoginActivity.user+"\nID : "+LoginActivity.id, Toast.LENGTH_LONG).show();

    }

    public void Oxygen(View view) {
        type="up";
        startActivity(new Intent(MainActivity.this,MainActivitylist.class));
    }

    public void temp(View view) {
        type="no";
        startActivity(new Intent(MainActivity.this,MainActivitylist.class));
    }


}