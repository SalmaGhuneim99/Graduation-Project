package com.example.iothealthcare;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class GetSectionData {
    public List<ReadsData> GetData()
    {
        List<ReadsData> data=new ArrayList<>();
        Database db=new Database();
        db.ConnectDB();
        ResultSet rs=db.RunSearch("select * from viewreads where studentid='"+LoginActivity.id+"'");
        try {
            while (rs.next())
            {
                ReadsData ss=new ReadsData();
                ss.setTemp(rs.getString(1));
                ss.setOxogen(rs.getString(2));
                ss.setStudentID(rs.getString(3));
                ss.setHeart(rs.getString(4));
                ss.setDate(rs.getString(5));
                data.add(ss);
            }
        }
        catch (SQLException ex)
        {
            ;
        }
        return data;
    }



    public List<ReadsData> GetDataNormal()
    {
        List<ReadsData> data=new ArrayList<>();
        Database db=new Database();
        db.ConnectDB();
        ResultSet rs=db.RunSearch("select * from viewreadsnormal where studentid='"+LoginActivity.id+"'");
        try {
            while (rs.next())
            {
                ReadsData ss=new ReadsData();
                ss.setTemp(rs.getString(1));
                ss.setOxogen(rs.getString(2));
                ss.setStudentID(rs.getString(3));
                ss.setHeart(rs.getString(4));
                ss.setDate(rs.getString(5));
                data.add(ss);
            }
        }
        catch (SQLException ex)
        {
            ;
        }
        return data;
    }



}
