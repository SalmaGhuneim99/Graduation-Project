package com.example.iothealthcare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivitylist extends AppCompatActivity {
    ListView lst;
    ReadsData model;
    GetSectionData g=new GetSectionData();
    AdapterSections adapterSections;
    ArrayList<ReadsData> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activitylist);

        lst=findViewById(R.id.lstreads);
        if(MainActivity.type.equals("up")) {
            data = new ArrayList<>(g.GetData());
            Toast.makeText(this, "UpNormal Read Data", Toast.LENGTH_LONG).show();
           adapterSections = new AdapterSections(this, data);
        }
        else
        {
            data = new ArrayList<>(g.GetDataNormal());
            Toast.makeText(this, "Normal Read Data", Toast.LENGTH_LONG).show();
            adapterSections = new AdapterSections(this, data);
        }
        Toast.makeText(this, ""+data.size(), Toast.LENGTH_SHORT).show();
        lst.setAdapter(adapterSections);
    }
}