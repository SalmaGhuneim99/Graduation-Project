package com.example.iothealthcare;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginActivity extends AppCompatActivity {

    EditText txtuser,txtpass;
public static String user,id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtuser=findViewById(R.id.txtphonelogin);
        txtpass=findViewById(R.id.txtpassllogin);
    }

    public void createacc(View view) {
        startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
    }

    public void loginnow(View view) {
        if(txtuser.getText().toString().isEmpty())
        {
            txtuser.setError("Please enter Phone");
            txtuser.requestFocus();
        }
        else {
            if (txtpass.getText().toString().isEmpty()) {
                txtpass.setError("Please enter password");
                txtpass.requestFocus();
            } else {

                Database db=new Database();
               Connection conn= db.ConnectDB();
               if(conn==null)
                   Toast.makeText(this, "no internet", Toast.LENGTH_SHORT).show();
                ResultSet rs=db.RunSearch("select * from student where phone='"+txtuser.getText()+"' and password='"+txtpass.getText()+"'");
                try {
                    if(rs.next())
                    {
                        user=rs.getString(2);
                        id=rs.getString(1);
                        //Toast.makeText(this, "ok", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginActivity.this,MainActivity.class));
                    }
                    else {
                        AlertDialog.Builder mm=new AlertDialog.Builder(LoginActivity.this);
                        mm.setIcon(R.drawable.logo);
                        mm.setTitle("Login.....");
                        mm.setMessage("Invaild Phone / Password Try Again");
                        mm.setPositiveButton("Thanks",null);
                        mm.setNegativeButton("Register Now", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));

                            }
                        });
                        mm.create();
                        mm.show();

                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }


            }
        }


    }

    public void forgetpass(View view) {
        startActivity(new Intent(LoginActivity.this,ForgetActivity.class));

    }
}